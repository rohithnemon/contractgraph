import json

class CodeEngineer:
    def __init__(self, model_client): self.model = model_client

    def generate_patch(self, contract, plan, context):
        prompt = ("Produce a minimal unified diff. Return ONLY JSON with keys summary, "
                  "unified_diff, files_changed. Do not include markdown fences. "
                  "Do not claim tests were run.\n"
                  f"CONTRACT:\n{json.dumps(contract.to_dict(), indent=2)}\n"
                  f"PLAN:\n{json.dumps(plan.to_dict(), indent=2)}\n"
                  f"CONTEXT:\n{context}")
        raw = self.model.generate(prompt, "You are a careful software engineer. Avoid unrelated edits.")
        try: data = json.loads(raw)
        except json.JSONDecodeError as e: raise ValueError(f"Code engineer returned invalid JSON: {e}") from e
        if not data.get("unified_diff"): raise ValueError("Model response contains no unified_diff")
        return data
