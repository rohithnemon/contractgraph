# ContractGraph

A Python research prototype for contract-guided, repository-graph-assisted agentic software engineering.

## Status and scope

This repository implements:
- Python AST indexing for files, imports, classes, functions, and syntactic call relationships.
- A JSON-serializable repository graph with deterministic lexical retrieval and dependency expansion.
- Structured task contracts, implementation plans, patch artifacts, test execution records, and verification evidence.
- A configurable Gemma-compatible model interface using an OpenAI-compatible HTTP chat-completions endpoint.
- Patch validation/application, test execution with timeouts, metric aggregation, CLI orchestration, logging, and unit tests.

Important limitations:
- AST relationships are syntactic, not full compiler-grade symbol resolution. Dynamic imports, reflection, runtime dispatch, and cross-language parsing are not resolved.
- The graph indexes Python source only.
- The model client requires a user-provided compatible endpoint and model identifier. It does not embed credentials or claim that a specific hosted Gemma 4 endpoint is available.
- The model-generated patch path has not been validated against a live Gemma deployment in this environment.
- Test execution is a subprocess with a timeout and environment controls, **not a hardened security sandbox**. Run untrusted code only in a disposable container/VM with OS-level isolation.
- Contract compliance is evidence-based heuristic verification; it is not a formal proof.
- No competition tasks or experimental measurements are bundled. Evaluation outputs are produced only when real tasks are run.

## Requirements

Python 3.10+ recommended. Install dependencies:

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Configure a model

Copy `configs/config.yaml` and set:
- `models.gemma.base_url`: base URL for an OpenAI-compatible API (for example, the provider's `/v1` base).
- `models.gemma.model`: exact model ID exposed by that endpoint.
- `models.gemma.api_key_env`: environment variable containing the API key.

Then export the key without putting it in source control:

```bash
export GEMMA_API_KEY="..."
```

The model client sends `POST {base_url}/chat/completions`. If your provider uses a different API shape, implement the small `ModelClient` interface in `models/gemma_client.py`.

## Run

Index a repository and save its graph:

```bash
python -m contractgraph.main index --repo /path/to/python/repository --output repository_graph.json
```

Run a task through the pipeline:

```bash
python -m contractgraph.main run \
  --repo /path/to/python/repository \
  --task "Add input validation to the user registration function" \
  --graph-output repository_graph.json \
  --output-dir runs/example
```

Run these module commands from the directory containing the `contractgraph/` folder.\n\nFor offline/deterministic inspection without model credentials, use:

```bash
python -m contractgraph.main index --repo . --output repository_graph.json
```

The full agentic run requires a configured model endpoint. The pipeline fails clearly if no endpoint is configured rather than fabricating a patch.

## Task contract format

The contract builder creates a contract with:
- `requirements`: explicit requirements extracted from task text (simple sentence/bullet splitting by default).
- `constraints`: constraints identified by conservative keyword rules.
- `acceptance_criteria`: criteria derived from requirements unless supplied explicitly.
- `source_task`: original task text.

For research-grade experiments, provide gold/annotated contracts or a validated contract-extraction prompt and report the annotation procedure. Automatic extraction is not guaranteed to capture every requirement.

## Patch format

The code engineer expects the model to return JSON:

```json
{
  "summary": "Short patch summary",
  "unified_diff": "diff --git ...",
  "files_changed": ["src/module.py"]
}
```

The patch manager validates paths and applies the unified diff using `git apply --check` and `git apply`. The repository must be a Git worktree for patch application. Use a clean disposable worktree per run.

## Tests

```bash
pytest -q
```

The tests use temporary local repositories and mock model responses. They do not require a network connection or API key.

## Evaluation

The evaluation module records per-task binary outcomes and resource use. See `evaluation/metrics.py` and `evaluation/evaluate.py`. Do not interpret missing measurements as failures or claim benchmark performance without running the benchmark. Keep task IDs, base commit, model ID/revision, prompt hash, test command, and raw evidence with every experimental run.

## Security and reproducibility

- Never run untrusted model patches on a host containing secrets.
- Use a disposable container/VM, non-root user, network restrictions, CPU/memory limits, and read-only mounts where appropriate.
- Pin the repository commit, dependencies, model revision, prompt, decoding parameters, and test command.
- Use the same tasks and isolated base state for B0-B3 ablations.
- Keep raw patches, model outputs, logs, test output, and run metadata.
