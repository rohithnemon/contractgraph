from ..execution.test_runner import TestRunner

class TestEngineer:
    def __init__(self, timeout_seconds=300): self.runner = TestRunner(timeout_seconds)
    def run(self, repo_path, command): return self.runner.run(repo_path, command)
