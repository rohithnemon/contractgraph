from contractgraph.contracts.contract_builder import build_contract

def test_build_contract_extracts_requirements_and_constraints():
    c = build_contract("Add login validation.\nMust not expose passwords.")
    assert len(c.requirements) == 2
    assert any("Must not" in x for x in c.constraints)
    assert c.metadata["requires_review"] is True
