"""Persist per-task raw measurements and aggregate summaries as CSV/JSON."""
import csv
import json
from pathlib import Path
from .metrics import TaskMetrics, aggregate

FIELDS = ["configuration", "task_id", "pass_at_1", "test_pass", "patch_correct",
          "contract_compliant", "regression", "tokens_used", "execution_time_seconds"]

def save_evaluation(rows: list[TaskMetrics], output_dir):
    out = Path(output_dir); out.mkdir(parents=True, exist_ok=True)
    with (out / "evaluation_results.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS); writer.writeheader()
        writer.writerows([r.to_dict() for r in rows])
    summary = aggregate(rows)
    (out / "evaluation_aggregates.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return summary
