"""ContractGraph command-line entry point."""
import argparse
import json
import logging
from pathlib import Path

from contractgraph.contracts.contract_builder import build_contract
from contractgraph.agents.repository_analyzer import RepositoryAnalyzer
from contractgraph.reasoning.graph_reasoner import GraphReasoner
from contractgraph.reasoning.context_retriever import format_context
from contractgraph.models.gemma_client import GemmaClient
from contractgraph.agents.planner import Planner
from contractgraph.agents.code_engineer import CodeEngineer
from contractgraph.agents.test_engineer import TestEngineer
from contractgraph.agents.verifier import Verifier
from contractgraph.execution.patch_manager import PatchManager
from contractgraph.evaluation.metrics import TaskMetrics
from contractgraph.evaluation.evaluate import save_evaluation

def load_config(path):
    try:
        import yaml
    except ImportError as exc:
        raise RuntimeError("PyYAML is required to load config.yaml; install requirements.txt") from exc
    return yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {}

def make_model(config):
    m = config.get("models", {}).get("gemma", {})
    return GemmaClient(m.get("base_url", ""), m.get("model", ""),
        m.get("api_key_env", "GEMMA_API_KEY"), m.get("timeout_seconds", 120),
        m.get("temperature", 0.1), m.get("max_tokens", 4096))

def run_pipeline(args, config):
    repo = Path(args.repo).resolve()
    if not repo.is_dir(): raise ValueError(f"Repository does not exist: {repo}")
    logging.info("Building repository graph")
    graph = RepositoryAnalyzer().analyze(str(repo), config.get("repository", {}))
    graph_path = Path(args.graph_output); graph.save(graph_path)
    contract = build_contract(args.task)
    nodes = GraphReasoner(graph).retrieve(args.task, config.get("reasoning", {}).get("max_context_nodes", 30),
                                          config.get("reasoning", {}).get("dependency_hops", 1))
    context = format_context(nodes)
    model = make_model(config)
    plan = Planner(model).create_plan(contract, context)
    patch = CodeEngineer(model).generate_patch(contract, plan, context)
    patch_manager = PatchManager()
    patch_manager.validate(repo, patch["unified_diff"])
    if args.apply:
        patch_manager.apply(repo, patch["unified_diff"])
    else:
        logging.info("Patch validated but not applied; pass --apply to apply it.")
    command = args.test_command or config.get("execution", {}).get("test_command", "pytest -q")
    evidence = TestEngineer(config.get("execution", {}).get("test_timeout_seconds", 300)).run(repo, command) if args.apply else None
    report = None
    if evidence:
        report = Verifier().verify(contract, evidence, [patch.get("summary", ""), plan.summary])
    output = Path(args.output_dir); output.mkdir(parents=True, exist_ok=True)
    result = {"contract": contract.to_dict(), "retrieved_nodes": nodes, "plan": plan.to_dict(),
              "patch": patch, "patch_applied": bool(args.apply),
              "test_evidence": evidence.to_dict() if evidence else None,
              "verification": report.to_dict() if report else None}
    (output / "run.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    if evidence:
        row = TaskMetrics("B3", args.task_id or "local-task",
            pass_at_1=int(evidence.passed), test_pass=int(evidence.passed),
            contract_compliant=int(report.compliant), execution_time_seconds=evidence.duration_seconds)
        save_evaluation([row], output / "evaluation")
    return result

def main():
    parser = argparse.ArgumentParser(description="ContractGraph research prototype")
    sub = parser.add_subparsers(dest="command", required=True)
    idx = sub.add_parser("index"); idx.add_argument("--repo", required=True); idx.add_argument("--output", default="repository_graph.json")
    run = sub.add_parser("run")
    run.add_argument("--repo", required=True); run.add_argument("--task", required=True)
    run.add_argument("--config", default="contractgraph/configs/config.yaml"); run.add_argument("--graph-output", default="repository_graph.json")
    run.add_argument("--output-dir", default="runs/default"); run.add_argument("--test-command")
    run.add_argument("--task-id"); run.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    if args.command == "index":
        graph = RepositoryAnalyzer().analyze(args.repo)
        graph.save(args.output); print(f"Indexed {len(graph.nodes)} nodes and {len(graph.edges)} edges to {args.output}")
    else:
        config = load_config(args.config)
        result = run_pipeline(args, config)
        print(json.dumps({"patch_applied": result["patch_applied"], "output_dir": args.output_dir}, indent=2))

if __name__ == "__main__": main()
