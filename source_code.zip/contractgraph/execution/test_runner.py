"""Timed subprocess test runner. This is not an OS security sandbox."""
import os
import shlex
import subprocess
import time
from ..contracts.schema import TestEvidence

class TestRunner:
    __test__ = False  # Prevent pytest from treating this production helper as a test class.
    def __init__(self, timeout_seconds=300): self.timeout_seconds = timeout_seconds

    def run(self, repo_path, command):
        start = time.monotonic()
        try:
            proc = subprocess.run(shlex.split(command), cwd=repo_path, capture_output=True,
                                  text=True, timeout=self.timeout_seconds,
                                  env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
            duration = time.monotonic() - start
            return TestEvidence(command, proc.returncode == 0, proc.returncode,
                                proc.stdout, proc.stderr, duration)
        except subprocess.TimeoutExpired as exc:
            duration = time.monotonic() - start
            stdout = exc.stdout.decode(errors="replace") if isinstance(exc.stdout, bytes) else (exc.stdout or "")
            stderr = exc.stderr.decode(errors="replace") if isinstance(exc.stderr, bytes) else (exc.stderr or "")
            return TestEvidence(command, False, None, stdout, stderr, duration, timed_out=True)
