"""Python AST parser. Relationships are syntactic approximations."""
import ast
from pathlib import Path
from typing import Any

def parse_python_file(path: str | Path, repo_root: str | Path) -> dict[str, Any]:
    path, root = Path(path), Path(repo_root)
    rel = path.resolve().relative_to(root.resolve()).as_posix()
    source = path.read_text(encoding="utf-8", errors="replace")
    tree = ast.parse(source, filename=rel)
    symbols, imports, calls = [], [], []
    class Visitor(ast.NodeVisitor):
        def __init__(self):
            self.scope = []
        def visit_ClassDef(self, node):
            name = ".".join(self.scope + [node.name])
            symbols.append({"name": node.name, "qualified_name": name, "kind": "class",
                            "line": node.lineno, "end_line": getattr(node, "end_lineno", node.lineno)})
            self.scope.append(node.name); self.generic_visit(node); self.scope.pop()
        def visit_FunctionDef(self, node):
            self._function(node)
        def visit_AsyncFunctionDef(self, node):
            self._function(node)
        def _function(self, node):
            name = ".".join(self.scope + [node.name])
            symbols.append({"name": node.name, "qualified_name": name, "kind": "function",
                            "line": node.lineno, "end_line": getattr(node, "end_lineno", node.lineno)})
            self.scope.append(node.name); self.generic_visit(node); self.scope.pop()
        def visit_Import(self, node):
            for alias in node.names:
                imports.append({"module": alias.name, "line": node.lineno})
        def visit_ImportFrom(self, node):
            imports.append({"module": node.module or "", "level": node.level, "line": node.lineno})
        def visit_Call(self, node):
            fn = node.func
            if isinstance(fn, ast.Name): name = fn.id
            elif isinstance(fn, ast.Attribute): name = fn.attr
            else: name = ""
            if name: calls.append({"name": name, "line": node.lineno})
            self.generic_visit(node)
    Visitor().visit(tree)
    return {"path": rel, "symbols": symbols, "imports": imports, "calls": calls,
            "line_count": len(source.splitlines()), "source": source}
