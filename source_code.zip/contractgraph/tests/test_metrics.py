from contractgraph.evaluation.metrics import TaskMetrics, aggregate

def test_aggregate_ignores_missing_values():
    rows = [TaskMetrics("B0", "t1", pass_at_1=1, tokens_used=10),
            TaskMetrics("B0", "t2", pass_at_1=0, tokens_used=None)]
    a = aggregate(rows)["B0"]
    assert a["completed_tasks"] == 2
    assert a["pass_at_1_mean"] == 0.5
    assert a["tokens_used_n"] == 1
