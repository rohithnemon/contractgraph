import json
from ..contracts.schema import ImplementationPlan, PlanStep

class Planner:
    def __init__(self, model_client): self.model = model_client

    def create_plan(self, contract, context):
        prompt = ("Return ONLY valid JSON with keys summary, steps, assumptions, risks. "
                  "Each step has step_id, description, target_nodes, requirement_ids, risks.\n"
                  f"CONTRACT:\n{json.dumps(contract.to_dict(), indent=2)}\n"
                  f"REPOSITORY CONTEXT:\n{context}")
        raw = self.model.generate(prompt, "You are a cautious software change planner.")
        try: data = json.loads(raw)
        except json.JSONDecodeError as e: raise ValueError(f"Planner returned invalid JSON: {e}") from e
        steps = [PlanStep(**s) for s in data.get("steps", [])]
        if not steps: raise ValueError("Planner returned an empty implementation plan")
        return ImplementationPlan(data.get("summary", ""), steps,
                                  data.get("assumptions", []), data.get("risks", []))
