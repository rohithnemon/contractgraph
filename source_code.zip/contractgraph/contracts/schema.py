"""Typed data structures shared by the ContractGraph pipeline."""
from dataclasses import asdict, dataclass, field
from typing import Any

@dataclass
class TaskContract:
    contract_id: str
    source_task: str
    requirements: list[str] = field(default_factory=list)
    constraints: list[str] = field(default_factory=list)
    acceptance_criteria: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "TaskContract":
        return cls(**data)

@dataclass
class PlanStep:
    step_id: str
    description: str
    target_nodes: list[str] = field(default_factory=list)
    requirement_ids: list[str] = field(default_factory=list)
    risks: list[str] = field(default_factory=list)

@dataclass
class ImplementationPlan:
    summary: str
    steps: list[PlanStep]
    assumptions: list[str] = field(default_factory=list)
    risks: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

@dataclass
class TestEvidence:
    command: str
    passed: bool
    exit_code: int | None
    stdout: str
    stderr: str
    duration_seconds: float
    timed_out: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

@dataclass
class VerificationReport:
    compliant: bool
    requirement_results: list[dict[str, Any]]
    test_evidence_present: bool
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
