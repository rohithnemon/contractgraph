from ..repository.graph_builder import build_repository_graph

class RepositoryAnalyzer:
    def analyze(self, repo_path, config=None):
        config = config or {}
        return build_repository_graph(repo_path,
            exclude_dirs=config.get("exclude_dirs"),
            max_file_bytes=config.get("max_file_bytes", 1_000_000))
