"""Conservative task-to-contract extraction; not a substitute for human annotation."""
import re
import uuid
from .schema import TaskContract

CONSTRAINT_TERMS = ("must", "must not", "should", "should not", "only", "without",
                    "compatible", "backward-compatible", "no ", "never", "limit")

def _sentences(text: str) -> list[str]:
    raw = re.split(r"[\n;]+|(?<=[.!?])\s+", text.strip())
    return [re.sub(r"^[\s\-*•\d.)]+", "", s).strip() for s in raw if s.strip()]

def build_contract(task_text: str, acceptance_criteria: list[str] | None = None) -> TaskContract:
    if not task_text or not task_text.strip():
        raise ValueError("task_text must be non-empty")
    parts = _sentences(task_text)
    requirements = parts or [task_text.strip()]
    constraints = [p for p in requirements if any(t in p.lower() for t in CONSTRAINT_TERMS)]
    criteria = acceptance_criteria if acceptance_criteria is not None else [
        f"Requirement addressed: {r}" for r in requirements
    ]
    return TaskContract(
        contract_id=f"cg-{uuid.uuid4().hex[:12]}",
        source_task=task_text,
        requirements=requirements,
        constraints=constraints,
        acceptance_criteria=criteria,
        metadata={"extractor": "heuristic-v1", "requires_review": True},
    )
