from ..contracts.schema import VerificationReport

class Verifier:
    """Heuristic evidence verifier; a requirement passes only with explicit evidence text."""
    def verify(self, contract, test_evidence, evidence_items=None):
        evidence_items = evidence_items or []
        corpus = " ".join(str(x).lower() for x in evidence_items)
        results = []
        for requirement in contract.requirements:
            # Do not infer code correctness from a passing test alone.
            terms = [t.lower() for t in requirement.split() if len(t) > 3]
            matched = bool(terms) and any(term in corpus for term in terms)
            results.append({"requirement": requirement, "supported_by_evidence": matched})
        warnings = ["Heuristic verifier; review requirement evidence manually."]
        if not test_evidence.passed:
            warnings.append("Automated test command did not pass.")
        return VerificationReport(
            compliant=all(r["supported_by_evidence"] for r in results) and test_evidence.passed,
            requirement_results=results,
            test_evidence_present=True,
            warnings=warnings,
        )
