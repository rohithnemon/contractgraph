"""Convert retrieved graph nodes into bounded model context."""
def format_context(nodes, max_chars=16000):
    chunks, used = [], 0
    for node in nodes:
        line = (f"[{node.get('kind','node')}] {node.get('id','')} "
                f"path={node.get('path','')} name={node.get('qualified_name', node.get('name',''))} "
                f"line={node.get('line','')}")
        if used + len(line) + 1 > max_chars: break
        chunks.append(line); used += len(line) + 1
    return "\n".join(chunks)
