"""Build a repository graph from Python files."""
import ast
from pathlib import Path
from .ast_parser import parse_python_file
from .graph_store import GraphStore

def build_repository_graph(repo_root: str | Path, exclude_dirs=None, max_file_bytes=1_000_000) -> GraphStore:
    root = Path(repo_root).resolve()
    excluded = set(exclude_dirs or [".git", ".venv", "venv", "__pycache__", "node_modules"])
    graph = GraphStore()
    parsed = []
    for path in sorted(root.rglob("*.py")):
        if any(part in excluded for part in path.relative_to(root).parts): continue
        try:
            if path.stat().st_size > max_file_bytes: continue
            parsed.append(parse_python_file(path, root))
        except (SyntaxError, UnicodeError, OSError, ValueError):
            continue
    module_nodes = {}
    symbol_nodes = {}
    for item in parsed:
        file_id = f"file:{item['path']}"
        graph.add_node(file_id, kind="file", path=item["path"], line_count=item["line_count"])
        module_nodes[item["path"]] = file_id
        for s in item["symbols"]:
            sid = f"symbol:{item['path']}::{s['qualified_name']}"
            graph.add_node(sid, kind=s["kind"], name=s["name"], qualified_name=s["qualified_name"],
                           path=item["path"], line=s["line"], end_line=s["end_line"])
            graph.add_edge(file_id, sid, "defines")
            symbol_nodes.setdefault(s["name"], []).append(sid)
    for item in parsed:
        file_id = module_nodes[item["path"]]
        for imp in item["imports"]:
            graph.add_node(f"import:{item['path']}::{imp['line']}::{imp['module']}",
                           kind="import", module=imp["module"], path=item["path"], line=imp["line"])
            iid = f"import:{item['path']}::{imp['line']}::{imp['module']}"
            graph.add_edge(file_id, iid, "imports")
            module = imp["module"].replace(".", "/")
            candidates = [p for p in module_nodes if p == module + ".py" or p.endswith("/" + module + ".py")
                          or p == module + "/__init__.py"]
            for target_path in candidates: graph.add_edge(file_id, module_nodes[target_path], "depends_on")
        for call in item["calls"]:
            for sid in symbol_nodes.get(call["name"], []):
                if graph.nodes[sid].get("path") != item["path"]:
                    graph.add_edge(file_id, sid, "calls")
    return graph
