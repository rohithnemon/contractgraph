from contractgraph.repository.graph_builder import build_repository_graph
from contractgraph.reasoning.graph_reasoner import GraphReasoner

def test_graph_indexes_symbols_and_retrieves(tmp_path):
    (tmp_path / "lib.py").write_text("def validate_user(value):\n    return bool(value)\n")
    (tmp_path / "main.py").write_text("from lib import validate_user\n\ndef run():\n    return validate_user('x')\n")
    graph = build_repository_graph(tmp_path)
    assert any(n.get("name") == "validate_user" for n in graph.nodes.values())
    found = GraphReasoner(graph).retrieve("validate user", max_nodes=10)
    assert found
