"""Metric recording and aggregation; no values are inferred when evidence is absent."""
from dataclasses import asdict, dataclass
from statistics import mean

@dataclass
class TaskMetrics:
    configuration: str
    task_id: str
    pass_at_1: int | None = None
    test_pass: int | None = None
    patch_correct: int | None = None
    contract_compliant: int | None = None
    regression: int | None = None
    tokens_used: int | None = None
    execution_time_seconds: float | None = None

    def to_dict(self): return asdict(self)

def aggregate(rows):
    fields = ["pass_at_1", "test_pass", "patch_correct", "contract_compliant",
              "regression", "tokens_used", "execution_time_seconds"]
    output = {}
    configs = sorted({r.configuration for r in rows})
    for cfg in configs:
        group = [r for r in rows if r.configuration == cfg]
        output[cfg] = {"completed_tasks": len(group)}
        for field in fields:
            values = [getattr(r, field) for r in group if getattr(r, field) is not None]
            output[cfg][f"{field}_mean"] = mean(values) if values else None
            output[cfg][f"{field}_n"] = len(values)
    return output
