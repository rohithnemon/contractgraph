"""Configurable OpenAI-compatible chat-completions client; credentials come from environment."""
import json
import os
import urllib.error
import urllib.request

class ModelError(RuntimeError): pass

class ModelClient:
    def generate(self, prompt: str, system: str = "") -> str:
        raise NotImplementedError

class GemmaClient(ModelClient):
    def __init__(self, base_url: str, model: str, api_key_env="GEMMA_API_KEY",
                 timeout_seconds=120, temperature=0.1, max_tokens=4096):
        self.base_url = (base_url or "").rstrip("/")
        self.model = model
        self.api_key_env = api_key_env
        self.timeout_seconds = timeout_seconds
        self.temperature = temperature
        self.max_tokens = max_tokens

    def generate(self, prompt: str, system: str = "") -> str:
        if not self.base_url or not self.model:
            raise ModelError("Gemma endpoint is not configured: set models.gemma.base_url and model")
        messages = []
        if system: messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        payload = {"model": self.model, "messages": messages,
                   "temperature": self.temperature, "max_tokens": self.max_tokens}
        headers = {"Content-Type": "application/json"}
        key = os.getenv(self.api_key_env, "")
        if key: headers["Authorization"] = f"Bearer {key}"
        request = urllib.request.Request(
            self.base_url + "/chat/completions",
            data=json.dumps(payload).encode("utf-8"), headers=headers, method="POST")
        try:
            with urllib.request.urlopen(request, timeout=self.timeout_seconds) as response:
                data = json.loads(response.read().decode("utf-8"))
            return data["choices"][0]["message"]["content"]
        except (urllib.error.URLError, TimeoutError, KeyError, IndexError, ValueError) as exc:
            raise ModelError(f"Model request failed: {exc}") from exc
