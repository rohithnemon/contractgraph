"""In-memory directed graph with JSON persistence; no external graph database required."""
import json
from pathlib import Path
from typing import Any

class GraphStore:
    def __init__(self):
        self.nodes: dict[str, dict[str, Any]] = {}
        self.edges: list[dict[str, str]] = []

    def add_node(self, node_id: str, **attrs):
        self.nodes[node_id] = {"id": node_id, **attrs}

    def add_edge(self, source: str, target: str, relation: str):
        if source in self.nodes and target in self.nodes:
            edge = {"source": source, "target": target, "relation": relation}
            if edge not in self.edges: self.edges.append(edge)

    def neighbors(self, node_id: str) -> list[str]:
        out = set()
        for e in self.edges:
            if e["source"] == node_id: out.add(e["target"])
            if e["target"] == node_id: out.add(e["source"])
        return sorted(out)

    def to_dict(self):
        return {"nodes": list(self.nodes.values()), "edges": self.edges}

    def save(self, path: str | Path):
        Path(path).write_text(json.dumps(self.to_dict(), indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path: str | Path):
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        g = cls()
        for n in data.get("nodes", []):
            n = dict(n); node_id = n.pop("id"); g.add_node(node_id, **n)
        for e in data.get("edges", []): g.add_edge(e["source"], e["target"], e["relation"])
        return g
