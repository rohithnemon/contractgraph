"""Deterministic lexical retrieval plus graph-neighborhood expansion."""
import re
from collections import deque
from ..repository.graph_store import GraphStore

def _tokens(text):
    return {part.lower() for token in re.findall(r"[A-Za-z_][A-Za-z0-9_]{1,}", text)
            for part in token.replace("_", " ").split() if len(part) > 1}

class GraphReasoner:
    def __init__(self, graph: GraphStore):
        self.graph = graph

    def retrieve(self, query: str, max_nodes=30, dependency_hops=1):
        terms = _tokens(query)
        scored = []
        for nid, node in self.graph.nodes.items():
            text = " ".join(str(node.get(k, "")) for k in ("name", "qualified_name", "path", "module"))
            overlap = len(terms & _tokens(text))
            if overlap: scored.append((overlap, nid))
        scored.sort(key=lambda x: (-x[0], x[1]))
        selected, queue = [], deque()
        for _, nid in scored:
            if nid not in selected:
                selected.append(nid); queue.append((nid, 0))
            if len(selected) >= max_nodes: break
        seen = set(selected)
        while queue and len(selected) < max_nodes:
            nid, depth = queue.popleft()
            if depth >= dependency_hops: continue
            for neighbor in self.graph.neighbors(nid):
                if neighbor not in seen:
                    seen.add(neighbor); selected.append(neighbor); queue.append((neighbor, depth + 1))
                    if len(selected) >= max_nodes: break
        return [self.graph.nodes[n] for n in selected]
