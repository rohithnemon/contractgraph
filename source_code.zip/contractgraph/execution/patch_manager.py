"""Validate and apply unified diffs using git; reject path traversal."""
import re
import subprocess
from pathlib import Path

class PatchError(RuntimeError): pass

def _validate_paths(diff: str):
    for line in diff.splitlines():
        if line.startswith(("+++ ", "--- ")):
            path = line[4:].strip().split("\t")[0]
            if path == "/dev/null": continue
            if path.startswith(("a/", "b/")): path = path[2:]
            p = Path(path)
            if p.is_absolute() or ".." in p.parts:
                raise PatchError(f"Unsafe patch path: {path}")

class PatchManager:
    def validate(self, repo_path, diff):
        _validate_paths(diff)
        proc = subprocess.run(["git", "apply", "--check", "--"],
            input=diff, text=True, capture_output=True, cwd=repo_path)
        if proc.returncode:
            raise PatchError(proc.stderr.strip() or "git apply --check failed")
        return True

    def apply(self, repo_path, diff):
        self.validate(repo_path, diff)
        proc = subprocess.run(["git", "apply", "--"],
            input=diff, text=True, capture_output=True, cwd=repo_path)
        if proc.returncode:
            raise PatchError(proc.stderr.strip() or "git apply failed")
        return True
