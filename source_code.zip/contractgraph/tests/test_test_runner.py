from contractgraph.execution.test_runner import TestRunner

def test_test_runner_records_success(tmp_path):
    result = TestRunner(5).run(tmp_path, "python -c 'print(123)'")
    assert result.passed
    assert "123" in result.stdout
