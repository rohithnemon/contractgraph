import pytest
from contractgraph.models.gemma_client import GemmaClient, ModelError

def test_unconfigured_model_fails_clearly():
    with pytest.raises(ModelError, match="not configured"):
        GemmaClient("", "").generate("hello")
