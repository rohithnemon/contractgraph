import subprocess
import pytest
from contractgraph.execution.patch_manager import PatchManager, PatchError

def test_patch_manager_applies_valid_diff(tmp_path):
    subprocess.run(["git", "init"], cwd=tmp_path, check=True, capture_output=True)
    (tmp_path / "a.txt").write_text("old\n")
    subprocess.run(["git", "add", "a.txt"], cwd=tmp_path, check=True)
    diff = "--- a/a.txt\n+++ b/a.txt\n@@ -1 +1 @@\n-old\n+new\n"
    PatchManager().apply(tmp_path, diff)
    assert (tmp_path / "a.txt").read_text() == "new\n"

def test_patch_manager_rejects_traversal():
    with pytest.raises(PatchError):
        PatchManager().validate("/tmp", "--- a/../secret\n+++ b/../secret\n@@ -1 +1 @@\n-a\n+b\n")
