from contractgraph.repository.graph_store import GraphStore

def test_graph_roundtrip(tmp_path):
    g = GraphStore(); g.add_node("a", kind="file"); g.add_node("b", kind="symbol")
    g.add_edge("a", "b", "defines")
    path = tmp_path / "g.json"; g.save(path)
    loaded = GraphStore.load(path)
    assert loaded.neighbors("a") == ["b"]
